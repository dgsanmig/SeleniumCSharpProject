﻿using System;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using ILSTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using NUnit.Framework;
using BoDi;
using OpenQA.Selenium.Chrome;

namespace ILSTestAutomation.Steps
{
    [Binding]
    public sealed class LoginSuccessSteps
    {
        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly IObjectContainer _objectContainer;
        private readonly ChromeDriver _driver;

        public LoginSuccessSteps(ObjectContainer objectContainer, ChromeDriver driver)
        {
            _objectContainer = objectContainer;
            _driver = driver;
        }

        [Given(@"I am in the Login Page of ILS")]
        public void GivenIAmInTheLoginPage()
        {
            _driver
                .Navigate()
                .GoToUrl("https://qac-portal.qac.awsdev.infor.com/LSP2_DEM");
        }

        [When(@"I input my username")]
        public void WhenIEnterMyUsername()
        {
            var userName = _driver.FindElement(By.XPath("//*[@id='username']"));
            userName.SendKeys("svc-lspautomation2@infor.com");
        }

        [When(@"I input my password")]
        public void WhenIEnterMyPassword()
        {
            var password = _driver.FindElement(By.XPath("//*[@id='password']"));
            password.SendKeys("Infor@pw01");
        }

        [When(@"I sign in")]
        public void WhenIClickSignIn()
        {
            var signIn = _driver.FindElement(By.LinkText("Sign On"));
            signIn.Click();
        }

        [Then(@"I should see that the homepage is loaded successfully")]
        public void ThenIShouldSeeTheHomepageLoaded()
        {
            WebDriverWait wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(20));
            _driver.SwitchTo().Frame("m-app-frame");
            IWebElement homeLabel =
                wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.CssSelector("data-mgcompnamevalue='HeaderTitleStatic'")));

            Assert.Equals(true, homeLabel.Displayed);
        }
    }
}
