﻿using OpenQA.Selenium.Chrome;

namespace ILSTestAutomation.Drivers
{
    class SetupDriver
    {
        public ChromeDriver _driver { get;}

        public SetupDriver()
        {
            _driver = new ChromeDriver();
        }
    }
}
