﻿using TechTalk.SpecFlow;
using ILSTestAutomation.Drivers;
using BoDi;
using OpenQA.Selenium.Chrome;

namespace ILSTestAutomation.Hooks
{
    [Binding]
    public sealed class HookInitialization
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        private readonly IObjectContainer _objectContainer;
        private ChromeDriver _driver;

        public HookInitialization(IObjectContainer objectContainer)
        {
            _objectContainer = objectContainer;
            _driver = new SetupDriver()._driver;
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
            _objectContainer.RegisterInstanceAs<ChromeDriver>(_driver);
            _driver.Manage().Window.Maximize();
        }

        [AfterScenario]
        public void AfterScenario()
        {
            _driver.Quit();
        }
    }
}
